﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace RTS_POE
{
    class GameEngine
    {


        int round = 1;

        Object selected;

        public Map battleMap = new Map(16,6);

        Random rnd = new Random();

        private GameWindow gameWindow;
        private GroupBox groupBox;
        private Panel pnlBattelField;

        public GameEngine(GameWindow gw, GroupBox gb, Panel pnl)
        {
            groupBox = gb;
            gameWindow = gw;
            pnlBattelField = pnl;
        }

        public int Round
        {
            get { return round; }
            set { round = value; }
        }

        public void UpdatePannle()
        {

            
            pnlBattelField.Controls.Clear();
            
            
            foreach (Unit u in battleMap.units)
            {
                Button b = new Button();
                b.Location = new Point(u.XPos * 35, u.YPos * 35);
                b.Size = new Size(30, 30);
                b.Text = u.Symbol;
                b.Font = new Font(b.Font.FontFamily, 13);
                if (u.Team == 0)
                {
                    b.BackColor = Color.Black;
                    b.ForeColor = Color.AntiqueWhite;
                }
                else
                {
                    b.BackColor = Color.AntiqueWhite;
                    b.ForeColor = Color.Black;
                }
                b.Click += unitClick;
                pnlBattelField.Controls.Add(b);
                
            }
            foreach (Building bu in battleMap.buildings)
            {
                Button b = new Button();
                b.Location = new Point(bu.XPos * 35, bu.YPos * 35);
                b.Size = new Size(35, 35);
                b.Text = bu.Symbol;
                b.Font = new Font(b.Font.FontFamily, 13);
                if (bu.Team == 0)
                {
                    b.BackColor = Color.Black;
                    b.ForeColor = Color.AntiqueWhite;
                }
                else
                {
                    b.BackColor = Color.AntiqueWhite;
                    b.ForeColor = Color.Black;
                }
                b.Click += buildingClick;
                pnlBattelField.Controls.Add(b);

            }
            gameWindow.Controls.Add(pnlBattelField);
        }

        public void unitClick(Object selectedUnit , EventArgs e)
        {
            foreach (Unit u in battleMap.units)
            {
                if (((((Button)selectedUnit).Location.X / 35)==u.XPos) && ((((Button)selectedUnit).Location.Y / 35) == u.YPos))
                {
                    gameWindow.displaySelected(u.ToString());
                }
            }
        }

        public void buildingClick(Object selectedBuilding, EventArgs e)
        {
            foreach (Building u in battleMap.buildings)
            {
                if (((((Button)selectedBuilding).Location.X / 35) == u.XPos) && ((((Button)selectedBuilding).Location.Y / 35) == u.YPos))
                {
                    gameWindow.displaySelected(u.ToString());
                }
            }
        }

        public void UpdateBuilding()
        {
            foreach (Building b in battleMap.buildings)
            {
                if ((b.GetType()).Equals(typeof(ResourceBuilding)))
                {
                    ((ResourceBuilding)b).Extract();
                }
                if ((b.GetType()).Equals(typeof(FactoryBuilding)))
                {

                    

                    if (Round % (((FactoryBuilding)b).ProductionSpeed) == 0)
                    {
                        Unit[] newUnits = new Unit[(battleMap.units.Length) + 1];
                        for (int i = 0; i < newUnits.Length-1; i++)
                        {
                            newUnits[i] = battleMap.units[i];
                        }
                        newUnits[newUnits.Length-1] = ((FactoryBuilding)b).Spawn();

                        battleMap.units = newUnits;
                    }
                }

            }
            this.UpdatePannle();

        }

        public void UpdateUnits()
        {
            foreach (Unit u in battleMap.units)
            {
                if (u.Health < (u.HealthMax * 0.25))
                {
                    u.move(rnd.Next(0, 2), rnd.Next(0, 2));
                }
                else
                {
                    if (u.inRange(u.nearby(battleMap.units)))
                    {
                        //combat
                    }
                    else
                    {
                        Unit enemy = u.nearby(battleMap.units);

                        // horisontal check
                        if ((u.XPos - enemy.XPos) == 0)
                        {
                            u.move(0, 0);
                        }
                        else if ((u.XPos-enemy.XPos) < 0)
                        {
                            u.move(1, 0);
                        }
                        else
                        {
                            u.move(2, 0);
                        }

                        //vertical check
                        if ((u.YPos - enemy.YPos) == 0)
                        {
                            u.move(0, 0);
                        }
                        else if ((u.YPos - enemy.YPos) < 0)
                        {
                            u.move(0, 1);
                        }
                        else
                        {
                            u.move(0, 2);
                        }
                    }
                }
            }
            this.UpdatePannle();
            
        }
    }
}
