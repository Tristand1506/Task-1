﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RTS_POE
{
    public partial class GameWindow : Form
    {
        //creates a new map with 20 units

        GameEngine engine;

        

        public void updateBattleLog(string info){
            lbxBattleLog.Items.Add(info);
        }

        public void displaySelected(string unitInfo)
        {
            rtbUnitInfo.Clear();
            rtbUnitInfo.Text = unitInfo;
        }
        
        public GameWindow()
        {
            InitializeComponent();
            engine = new GameEngine(this, this.gbxUntilUI,this.pnlBattleField);

            engine.UpdatePannle();
        }

        private void lblRound_Click(object sender, EventArgs e)
        {

        }

        private void btnStartStop_Click(object sender, EventArgs e)
        {
            tmrClock.Start();
           
        }

        private void TmrClock_Tick(object sender, EventArgs e)
        {
            engine.UpdateUnits();
            engine.UpdateBuilding();
            lblRound.Text = "Round " + engine.Round;
            engine.Round += 1;
        }

        private void BtnPause_Click(object sender, EventArgs e)
        {
            tmrClock.Stop();
        }
    } 
}
